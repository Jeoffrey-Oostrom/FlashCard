class Practice < ActiveRecord::Base
end
