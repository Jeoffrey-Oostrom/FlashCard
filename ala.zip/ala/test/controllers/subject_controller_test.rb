require 'test_helper'

class SubjectControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
