require 'test_helper'

class VisitorControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
