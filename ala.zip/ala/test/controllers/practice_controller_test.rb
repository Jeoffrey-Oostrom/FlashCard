require 'test_helper'

class PracticeControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
